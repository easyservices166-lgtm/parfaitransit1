// Configuration simple à modifier avant publication
const COMPANY_EMAIL = "info@parfaitransit.com"; // Remplacer si l'adresse officielle change
const WHATSAPP_NUMBER = "971557736803";
const PHONE_NUMBER = "+971568689788";

const translations = {
  fr: {
    skip:"Aller au contenu",topline:"ACHATS DE VÉHICULES • TRANSPORT INTERNATIONAL • LOGISTIQUE & DOUANE",availability:"Disponible 24h/24 et 7j/7",tagline:"ACHATS VÉHICULES & TRANSPORT<br>LOGISTICS & DOUANE",phone:"Téléphone",
    navHome:"⌂ Accueil",navAbout:"À propos",navVehicles:"Achat de véhicules",navTransport:"Transport international",navCustoms:"Transit et douane",navGallery:"Galerie",navContact:"Contact",quote:"Demander un devis",
    heroEyebrow:"VOTRE PARTENAIRE AUTOMOBILE & LOGISTIQUE",heroTitle:"Vos véhicules,<br><em>de l'achat à la livraison.</em>",heroText:"Achat de véhicules fiables, transport international sécurisé, transit et dédouanement simplifié vers la RDC, le Gabon, la Tanzanie, le Kenya et d’autres pays.",heroService1:"Achat de<br>véhicules",heroService2:"Transport<br>international",heroService3:"Transit<br>et douane",whatsapp:"Discuter sur WhatsApp",callUs:"Nous appeler",
    corridorEyebrow:"NOS AXES INTERNATIONAUX",corridorTitle:"Nos corridors <em>de transport internationaux</em>",andOthers:"et autres pays",korea:"Corée du Sud",usa:"États-Unis",
    servicesEyebrow:"NOTRE SAVOIR-FAIRE",servicesTitle:"Nos <em>services</em>",serviceVehicleTitle:"Achat de véhicules",serviceVehicleText:"Nous vous accompagnons dans la recherche et l'achat de véhicules adaptés à vos besoins.",serviceTransportTitle:"Transport international",serviceTransportText:"Transport maritime et aérien fiable et sécurisé depuis Dubaï, la Corée du Sud, la Chine, le Japon et les États-Unis.",serviceCustomsTitle:"Transit et douane",serviceCustomsText:"Gestion du transit, des formalités douanières et du dédouanement dans les pays de destination.",
    galleryEyebrow:"NOTRE SÉLECTION",galleryTitle:"Galerie <small>(exemples de véhicules)</small>",viewGallery:"Voir toute la galerie ↗",aboutEyebrow:"QUI SOMMES-NOUS ?",aboutTitle:"Un partenaire fiable,<br><em>au cœur de vos échanges.</em>",aboutIntro:"PARFAITRANSIT accompagne les particuliers et les professionnels dans leurs projets d'achat de véhicules et de transport international. Nous coordonnons les différentes étapes pour rendre chaque opération plus claire et plus simple.",mission:"Notre mission",missionText:"Faciliter l'achat et l'acheminement de véhicules entre les marchés internationaux et vos destinations.",vision:"Notre vision",visionText:"Construire un réseau de services fiable, transparent et tourné vers l'international.",values:"Nos valeurs",valuesText:"Transparence, sérieux, disponibilité et accompagnement personnalisé.",
    ctaEyebrow:"PARLONS DE VOTRE PROJET",ctaTitle:"Un projet d'achat ou de transport ?",ctaText:"Notre équipe est disponible pour étudier votre demande.",ctaButton:"Contactez-nous",contactEyebrow:"NOUS SOMMES À VOTRE ÉCOUTE",contactTitle:"Parlons de<br><em>votre prochain projet.</em>",contactIntro:"Envoyez-nous les détails de votre recherche. Nous vous répondrons pour préciser les possibilités et les prochaines étapes.",address:"Adresse",hours:"Disponibilité",hoursText:"24h/24 et 7j/7 • Bureau : lundi–vendredi (horaires à confirmer)",formTitle:"Demander un devis",formName:"Nom complet",formDestination:"Pays de destination",choose:"Choisir un pays",otherCountry:"Autre pays",formVehicle:"Véhicule recherché",formMessage:"Votre message",sendWhatsapp:"Envoyer sur WhatsApp",formNote:"Votre demande sera préparée dans WhatsApp. Aucune donnée n'est enregistrée sur ce site.",footerText:"Achats de véhicules, transport international, logistique et douane.",office:"Bureau",officeHours:"Lundi–Vendredi (à confirmer)",rights:"Tous droits réservés.",namePlaceholder:"Votre nom",vehiclePlaceholder:"Ex. Mercedes G63, Toyota Prado...",messagePlaceholder:"Décrivez votre besoin...",formSuccess:"Votre message est prêt. WhatsApp va s'ouvrir."
  },
  en: {
    skip:"Skip to content",topline:"VEHICLE SOURCING • INTERNATIONAL SHIPPING • LOGISTICS & CUSTOMS",availability:"Available 24/7",tagline:"VEHICLE SOURCING & TRANSPORT<br>LOGISTICS & CUSTOMS",phone:"Phone",
    navHome:"⌂ Home",navAbout:"About us",navVehicles:"Vehicle sourcing",navTransport:"International shipping",navCustoms:"Transit & customs",navGallery:"Gallery",navContact:"Contact",quote:"Request a quote",
    heroEyebrow:"YOUR AUTOMOTIVE & LOGISTICS PARTNER",heroTitle:"Your vehicles,<br><em>from purchase to delivery.</em>",heroText:"Reliable vehicle sourcing, secure international shipping, transit and simplified customs clearance to the DRC, Gabon, Tanzania, Kenya and other destinations.",heroService1:"Vehicle<br>sourcing",heroService2:"International<br>shipping",heroService3:"Transit &<br>customs",whatsapp:"Chat on WhatsApp",callUs:"Call us",
    corridorEyebrow:"OUR INTERNATIONAL ROUTES",corridorTitle:"Our international <em>shipping corridors</em>",andOthers:"and other countries",korea:"South Korea",usa:"United States",
    servicesEyebrow:"WHAT WE DO",servicesTitle:"Our <em>services</em>",serviceVehicleTitle:"Vehicle sourcing",serviceVehicleText:"We help you find and purchase vehicles that match your needs and requirements.",serviceTransportTitle:"International shipping",serviceTransportText:"Reliable and secure sea and air freight from Dubai, South Korea, China, Japan and the United States.",serviceCustomsTitle:"Transit & customs",serviceCustomsText:"Transit coordination, customs formalities and clearance support in destination countries.",
    galleryEyebrow:"OUR SELECTION",galleryTitle:"Gallery <small>(sample vehicles)</small>",viewGallery:"View full gallery ↗",aboutEyebrow:"WHO WE ARE",aboutTitle:"A reliable partner,<br><em>connecting your business.</em>",aboutIntro:"PARFAITRANSIT supports individuals and businesses with vehicle sourcing and international shipping projects. We coordinate the different steps to make every operation clearer and easier.",mission:"Our mission",missionText:"Make vehicle sourcing and delivery between international markets and your destination easier.",vision:"Our vision",visionText:"Build a reliable, transparent service network with an international outlook.",values:"Our values",valuesText:"Transparency, professionalism, availability and personal support.",
    ctaEyebrow:"LET'S DISCUSS YOUR PROJECT",ctaTitle:"Planning a purchase or shipment?",ctaText:"Our team is available to review your request.",ctaButton:"Contact us",contactEyebrow:"WE'RE HERE TO HELP",contactTitle:"Let's discuss<br><em>your next project.</em>",contactIntro:"Send us the details of your request. We will get back to you to discuss options and next steps.",address:"Address",hours:"Availability",hoursText:"24/7 • Office: Monday–Friday (hours to be confirmed)",formTitle:"Request a quote",formName:"Full name",formDestination:"Destination country",choose:"Select a country",otherCountry:"Other country",formVehicle:"Vehicle you're looking for",formMessage:"Your message",sendWhatsapp:"Send via WhatsApp",formNote:"Your request will be prepared in WhatsApp. No data is stored on this website.",footerText:"Vehicle sourcing, international shipping, logistics and customs.",office:"Office",officeHours:"Monday–Friday (to be confirmed)",rights:"All rights reserved.",namePlaceholder:"Your name",vehiclePlaceholder:"e.g. Mercedes G63, Toyota Prado...",messagePlaceholder:"Tell us what you need...",formSuccess:"Your message is ready. WhatsApp will open."
  }
};

function setLanguage(lang) {
  const dictionary = translations[lang] || translations.fr;
  document.documentElement.lang = lang;
  document.querySelectorAll("[data-i18n]").forEach(el => {
    const key = el.dataset.i18n;
    if (dictionary[key] !== undefined) el.innerHTML = dictionary[key];
  });
  document.querySelectorAll(".lang-btn").forEach(btn => {
    const active = btn.dataset.lang === lang;
    btn.classList.toggle("active", active);
    btn.setAttribute("aria-pressed", String(active));
  });
  const name = document.querySelector("#name");
  const vehicle = document.querySelector("#vehicle");
  const message = document.querySelector("#message");
  if (name) name.placeholder = dictionary.namePlaceholder;
  if (vehicle) vehicle.placeholder = dictionary.vehiclePlaceholder;
  if (message) message.placeholder = dictionary.messagePlaceholder;
  document.title = lang === "fr"
    ? "PARFAITRANSIT | Achats de véhicules & transport international"
    : "PARFAITRANSIT | Vehicle sourcing & international shipping";
  const description = lang === "fr"
    ? "PARFAITRANSIT accompagne vos achats de véhicules, le transport international, le transit et les formalités douanières."
    : "PARFAITRANSIT supports vehicle sourcing, international shipping, transit and customs clearance.";
  document.querySelector('meta[name="description"]')?.setAttribute("content", description);
  localStorage.setItem("parfaitransit-language", lang);
}

document.querySelectorAll(".lang-btn").forEach(btn => btn.addEventListener("click", () => setLanguage(btn.dataset.lang)));
setLanguage(localStorage.getItem("parfaitransit-language") || "fr");

const menuButton = document.querySelector(".menu-toggle");
const navLinks = document.querySelector(".nav-links");
menuButton?.addEventListener("click", () => {
  const expanded = menuButton.getAttribute("aria-expanded") === "true";
  menuButton.setAttribute("aria-expanded", String(!expanded));
  navLinks.classList.toggle("open", !expanded);
});
navLinks?.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  navLinks.classList.remove("open");
  menuButton?.setAttribute("aria-expanded", "false");
}));

const track = document.querySelector("#gallery-track");
document.querySelector(".gallery-control.prev")?.addEventListener("click", () => track.scrollBy({left: -track.clientWidth * .75, behavior:"smooth"}));
document.querySelector(".gallery-control.next")?.addEventListener("click", () => track.scrollBy({left: track.clientWidth * .75, behavior:"smooth"}));

document.querySelector("#contact-form")?.addEventListener("submit", event => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const lang = document.documentElement.lang;
  const text = lang === "fr"
    ? `Bonjour PARFAITRANSIT, je souhaite demander un devis.\\nNom : ${form.get("name")}\\nPays de destination : ${form.get("destination")}\\nVéhicule recherché : ${form.get("vehicle") || "Non précisé"}\\nMessage : ${form.get("message")}`
    : `Hello PARFAITRANSIT, I would like to request a quote.\\nName: ${form.get("name")}\\nDestination country: ${form.get("destination")}\\nVehicle: ${form.get("vehicle") || "Not specified"}\\nMessage: ${form.get("message")}`;
  document.querySelector("#form-feedback").textContent = translations[lang].formSuccess;
  window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`, "_blank", "noopener");
});

document.querySelectorAll('a[href^="mailto:"]').forEach(link => link.href = `mailto:${COMPANY_EMAIL}`);
const emailDisplay = document.querySelector("#email-display");
const footerEmail = document.querySelector("#footer-email");
if (emailDisplay) emailDisplay.textContent = COMPANY_EMAIL;
if (footerEmail) footerEmail.textContent = COMPANY_EMAIL;
document.querySelector("#year").textContent = new Date().getFullYear();
