# PARFAITRANSIT — site vitrine bilingue

Site vitrine responsive en HTML, CSS et JavaScript natifs. Aucun framework, aucune dépendance JavaScript, aucune commande de build.

## Contenu
- Français / English avec mémorisation de la langue choisie dans le navigateur.
- En-tête responsive et menu burger sur mobile.
- Bannière principale, corridors internationaux, services, galerie carrousel, À propos, formulaire WhatsApp et pied de page.
- Liens WhatsApp, téléphone, e-mail et Google Maps.
- SEO de base, Open Graph, favicon PT, navigation clavier et focus visible.

## Déploiement GitHub puis Netlify

1. Décompressez le ZIP sur votre ordinateur.
2. Ouvrez votre dépôt GitHub `parfaitransit`.
3. Choisissez **Add file → Upload files** et téléversez le contenu du dossier (pas le dossier parent) à la racine du dépôt. Vérifiez que `index.html`, `css/`, `js/`, `img/` et `netlify.toml` sont visibles à la racine.
4. Validez avec **Commit changes**.
5. Dans Netlify, connectez le dépôt GitHub `parfaitransit` (branche `main`).
6. Réglez **Base directory** : laisser vide ; **Build command** : laisser vide ; **Publish directory** : `.`. Le fichier `netlify.toml` contient déjà `publish = "."`.
7. Cliquez sur **Deploy**. Netlify publiera directement le dossier racine, sans étape de compilation.

## Coordonnées à modifier

Dans `js/main.js`, en haut du fichier :

```js
const COMPANY_EMAIL = "info@parfaitransit.com";
const WHATSAPP_NUMBER = "971557736803";
const PHONE_NUMBER = "+971568689788";
```

- `COMPANY_EMAIL` est centralisé pour pouvoir le remplacer facilement si l'adresse n'est pas confirmée.
- Le numéro WhatsApp doit rester au format international, chiffres uniquement, sans `+` ni espaces.
- Le téléphone visible est `+971 56 868 9788` et son lien `tel:` est dans `index.html`. Si ce numéro change, modifier aussi les liens `tel:` du HTML.
- L'adresse Google Maps est intégrée dans les liens de contact et du pied de page.
- Les horaires du bureau sont indiqués « à confirmer ».

## Remplacer les images

Les images sont dans `img/` et peuvent être remplacées en conservant exactement les noms de fichiers :

| Fichier | Utilisation |
|---|---|
| `brand-logo.webp` | Logo de l'en-tête, de la section À propos et du pied de page |
| `hero.webp` | Image principale de la bannière |
| `dubai.webp`, `korea.webp`, `china.webp`, `japan.webp`, `usa.webp` | Cartes des corridors |
| `service-vehicles.webp`, `service-shipping.webp`, `service-customs.webp` | Images des services |
| `vehicle-1.webp` à `vehicle-6.webp` | Galerie de véhicules |
| `favicon.svg` | Icône d'onglet avec monogramme PT |

Conseils : utilisez vos photos autorisées, recadrez-les au bon format, exportez en WebP ou JPG optimisé (qualité 80–88), puis remplacez le fichier correspondant en gardant le même nom. Les balises `alt` descriptives sont déjà présentes dans `index.html` ; adaptez-les si la photo change de sujet.

## Formulaire

Le formulaire ne stocke aucune donnée. Il compose le message et ouvre WhatsApp vers le numéro configuré. Le visiteur doit confirmer l'envoi dans WhatsApp.

## Test local

Aucun serveur ni installation n'est nécessaire : ouvrez simplement `index.html` dans un navigateur. Pour un test fidèle aux chemins de production, vous pouvez aussi utiliser un serveur statique local.

## Note sur les visuels

Les images incluses sont des découpes de la maquette fournie, utilisées comme visuels de démonstration. Remplacez-les par les photos réelles de l'entreprise avant une campagne commerciale si nécessaire.
